sexos = (
 ('F', 'Femenino'),
 ('M', 'Masculino')
)