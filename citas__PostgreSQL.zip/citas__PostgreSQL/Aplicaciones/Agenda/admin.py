from django.contrib import admin
from .models import Cita, Doctor


# Register your models here.
@admin.register(Cita)
class CitaAdmin(admin.ModelAdmin):
 list_display = ('id', 'nombreColor', 'creditos')
 search_fields = ('nombre', 'creditos')
 ##list_editable = ('nombre','creditos')
 list_filter = ('creditos',)
 list_per_page = 2
 
 def nombreCita(self,obj):
    return obj.nombre.upper()

 nombreCita.short_description = "Nombre del curso"

 nombreCita.admin_order_field = 'nombre'
 admin.site.register(Doctor)