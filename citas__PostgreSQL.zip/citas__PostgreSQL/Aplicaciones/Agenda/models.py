from django.db import models
from django.utils.html import format_html
from .choices import sexos

# Create your models here.
class Doctor(models.Model):
    apellido_paterno = models.CharField(max_length=20, verbose_name='Apellido Paterno')
    apellido_materno = models.CharField(max_length=20, verbose_name='Apellido Materno')
    nombres = models.CharField(max_length=20, verbose_name='Nombres')
    fecha_nacimiento = models.DateField(verbose_name='Fecha de Nacimiento')
    sexo = models.CharField(max_length=1, choices=sexos, default='F')
    
    def nombre_completo(self):
        return "{} {}, {}".format(self.apellido_paterno, self.apellido_materno, self.nombres)
    def __str__(self):
        return self.nombre_completo()
    class Meta:
        verbose_name = 'Doctor'
        verbose_name_plural = 'Doctor'
        db_table = 'doctor'

class Cita(models.Model):
    nombre = models.CharField(max_length=30)
    fecha = models.DateField(verbose_name='Fecha')
    creditos = models.PositiveSmallIntegerField()
    doctor = models.ForeignKey(Doctor, null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

    def nombreColor(self):
        if(self.creditos>3):
            return format_html('<span style="color:blue;">{0}</span>'.format(self.nombre))
        else:
            return format_html('<span style="color:green;">{0}</span>'.format(self.nombre))



