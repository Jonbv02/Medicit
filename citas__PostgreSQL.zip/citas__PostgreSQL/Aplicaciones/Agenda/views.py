from django.shortcuts import render
from django.http import HttpResponse
from .models import Cita, Doctor
from django.views.generic import ListView

# Create your views here.
def home(request):
    citasListado = Cita.objects.all()
    data = {
        'titulo': 'Listado de Citas',
        'citas': citasListado 
    }
    return render(request, "citas.html", data)

class CitaListView(ListView):
    model = Cita
    template_name = 'citas.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(*kwargs)
        context['titulo'] = 'Listado de Citas'
        return context
